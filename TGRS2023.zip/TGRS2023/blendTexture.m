% function [ imgout ] = blendTexture(warped_img1, warped_img2)
    %% preparation: parameter initialization
    patchsize = 21; % the size of patch for seam evaluation
    warning off;
    img1 = im2double(imread('5.png'));  % ��ƴ��ͼ
    img2 = im2double(imread('6.png'));  % ��׼ͼ
    img1 = imresize(img1, 0.5);
    img2 = imresize(img2, 0.5);
    warped_img1=img1;warped_img2=img2;
    gray1 = rgb2gray(warped_img1);  gray2 = rgb2gray(warped_img2);  
%         gray1 = warped_img1;  gray2 = warped_img2;  
    square_SE = strel('square', 5);
    signal_mu = 0.12;   %parameters for f(x)=exp(sigma_ratio*(x-mu))
    sigma_ratio = 5;
    
    %%  pre-process of seam-cutting
    w1 = imfill(imbinarize(gray1, 0),'holes');%��ֵ��
    w2 = imfill(imbinarize(gray2, 0),'holes');
    A = w1;  B = w2;
    C = A & B;  % overlapping region
    [sz1, sz2] = size(C);
    ind = find(C);  %���ҷ�0Ԫ��
    nNodes = size(ind,1);
    revindC = zeros(sz1*sz2,1);
    revindC(C)=1:length(ind);
    
    [tmp_y, tmp_x] = find(B==1);
    B_x0 = tmp_x(1); B_y0 = tmp_y(1);  % begining coordinates of reference in final canvas
    B_x1 = tmp_x(end); B_y1 = tmp_y(end); % ending coordinates of reference in final canvas
    
    gray_cut1 = gray1(B_y0:B_y1,B_x0:B_x1);
    gray_cut2 = gray2(B_y0:B_y1,B_x0:B_x1);
    C_cut = C(B_y0:B_y1,B_x0:B_x1);
    
    %%  calculate the data term of the energy function in graph cuts
    % boundary of overlapping region
    BR=(B-[B(:,2:end) false(sz1,1)])>0;
    BL=(B-[false(sz1,1) B(:,1:end-1)])>0;
    BD=(B-[B(2:end,:);false(1,sz2)])>0;
    BU=(B-[false(1,sz2);B(1:end-1,:)])>0;

    CR=(C-[C(:,2:end) false(sz1,1)])>0;
    CL=(C-[false(sz1,1) C(:,1:end-1)])>0;
    CD=(C-[C(2:end,:);false(1,sz2)])>0;
    CU=(C-[false(1,sz2);C(1:end-1,:)])>0;

    imgseedR = (BR|BL|BD|BU)&(CR|CL|CD|CU);
    imgseedB = (CR|CL|CD|CU) & ~imgseedR; 
    
    % data term
    tw=zeros(nNodes,2);
    tw(revindC(imgseedB),2) = inf;
    tw(revindC(imgseedR),1) = inf;
    
    terminalWeights = tw;       % data term

    %% calculate the smoothness term of the energy function
    CL1=C&[C(:,2:end) false(sz1,1)];
    CL2=[false(sz1,1) CL1(:,1:end-1)];
    CU1=C&[C(2:end,:);false(1,sz2)];
    CU2=[false(1,sz2);CU1(1:end-1,:)];
   
    %  edgeWeights:  Euclidean norm
    %--- Smoothness term 
 ang_1 = warped_img1(:,:,1); sat_1 = warped_img1(:,:,2); val_1 = warped_img1(:,:,3);
    ang_2 = warped_img2(:,:,1); sat_2 = warped_img2(:,:,2); val_2 = warped_img2(:,:,3);
%      ang_1 = warped_img1; 
%      ang_2 = warped_img2; 
    % basic difference map
    imgdif = sqrt( ( (ang_1.*C-ang_2.*C).^2+(sat_1.*C-sat_2.*C).^2+ (val_1.*C-val_2.*C).^2 )./3);
%      imgdif = (ang_1.*C-ang_2.*C);

    [Gmag1,~] = imgradient((gray1),'sobel'); [Gmag2,~] = imgradient((gray2),'sobel');
     Gmag=Gmag1-Gmag2;
     Gmag=Gmag.*C;Gmag=abs(Gmag);   %���ܴ��и���
%      imgdif=imgdif*1+Gmag*1+wcc;

%     imgdif_cut = imgdif(B_y0:B_y1,B_x0:B_x1);   
        
    DL = (imgdif(CL1)+imgdif(CL2))./2;
    DU = (imgdif(CU1)+imgdif(CU2))./2;
    
    % smoothness term
    edgeWeights=[
        revindC(CL1) revindC(CL2) DL+1e-8 DL+1e-8;
        revindC(CU1) revindC(CU2) DU+1e-8 DU+1e-8
    ];

    %%  graph-cut labeling
    [~, labels] = graphCutMex(terminalWeights, edgeWeights); 
    
    As=A;  Bs=B; 
    As(ind(labels==1))=false;   % 
    Bs(ind(labels==0))=false;   % reference
    % possion image blending
    imgout = gradientBlend(warped_img1, As, warped_img2); 
    
    final_As = As; 
    final_out = gradientBlend(warped_img1, final_As, warped_img2);
    final_Bs = (A|B) & ~final_As;
    C_seam = imdilate(final_As, square_SE) & imdilate(final_Bs, square_SE) & C;
%     C_seam = final_As & imdilate(final_Bs, square_SE) & C;  &��ϸ
%     C_seam=uint8(C_seam);
% [a,b]=find((C_seam * 250)==250);
% I_line=[a,b];
% sum=0;
% img1 = imread('r8.png');
% img2 = imread('r9.png');
% for i=1:size(I_line,1)
%     I_temp1=img1(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
%     I_temp2=img2(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
%   [mssim,~] =  ssim(I_temp1,I_temp2);
%   sum=sum+mssim;
% end
% ssim=sum/size(I_line,1);

%     C_seam = imdilate(As, square_SE) & imdilate(Bs, square_SE) & C;
    final_seam = final_out;
    final_seam(cat(3, C_seam, C_seam, C_seam)) = [ones(sum(C_seam(:)),1); ones(2*sum(C_seam(:)),1)];
%     fprintf('final output comes from k_seam = %d\n', k_seam-1);
%     figure,imshow(final_out);
    figure,imshow(final_seam);
      imgout(:,:,1)=imgout(:,:,1)+C_seam;imgout(:,:,1)=imgout(:,:,1).*C;
      imgout(:,:,2)=imgout(:,:,2)+C_seam;imgout(:,:,2)=imgout(:,:,2).*C;
      imgout(:,:,3)=imgout(:,:,3)+C_seam;imgout(:,:,3)=imgout(:,:,3).*C;
     imgout(imgout==0)=1;
%      imshow(imgout)
% end
D=A-C;
i3(:,:,1)=img1(:,:,1).*D+img2(:,:,1)+C_seam;
i3(:,:,2)=img1(:,:,2).*D+img2(:,:,2)+C_seam;
i3(:,:,3)=img1(:,:,3).*D+img2(:,:,3)+C_seam;
% i3(i3==0)=1;
% imwrite(final_seam,'t3.png');