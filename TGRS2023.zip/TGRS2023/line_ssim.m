% clc;clear all;close all;
I1 = imread('r8.png');
I2 = imread('r9.png');
% img1=imread('r8.png');img2=imread('r9.png');
load mask1.mat;
load mask2.mat;
mask1=uint8(mask1);mask2=uint8(mask2);
%     mask1 = imresize(mask1, 0.5);    mask2 = imresize(mask2, 0.5);
[msk1, msk2, seam]=SeamEstimation(I1, I2, mask1, mask2);
% stitched_image=uint8(msk1).*I1+uint8(msk2).*I2;
stitched_image1=repmat(uint8(msk1),[1,1,3]).*I1+repmat(uint8(msk2),[1,1,3]).*I2;
% stitched_image1(stitched_image1(:,:,:)==0)=255;
% imshow(stitched_image1);
% figure, imshow(stitched_image);
[a,b]=find((seam * 250)==250);
I_line=[a,b];
sum=0;
for i=1:size(I_line,1)
    I_temp1=I1(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
    I_temp2=I2(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
  [mssim,~] =  ssim(I_temp1,I_temp2);
  sum=sum+mssim;
end
ssim=sum/size(I_line,1);

