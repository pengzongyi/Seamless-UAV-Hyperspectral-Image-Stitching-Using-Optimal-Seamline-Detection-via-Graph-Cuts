
% img1 = im2double(imread('r8.png'));  % ��ƴ��ͼ
% img2 = im2double(imread('r9.png'));  % ��׼ͼ
% img1 = imresize(img1, 0.5);
% img2 = imresize(img2, 0.5);
a1=cell2mat(struct2cell(load('g8p_176.mat')));
 a1 = imresize(a1, 0.5);
a2=cell2mat(struct2cell(load('g9p_176.mat')));
 a2 = imresize(a2, 0.5);
% warped_img1=img1;warped_img2=img2;
% gray1 = rgb2gray(warped_img1);  gray2 = rgb2gray(warped_img2);  

%     w1 = imfill(imbinarize(gray1, 0),'holes');%��ֵ��
%     w2 = imfill(imbinarize(gray2, 0),'holes');
 w1 = imfill(imbinarize(a1(:,:,1), 0),'holes');w2 = imfill(imbinarize(a2(:,:,1), 0),'holes');
    A = w1;  B = w2;
    C = A & B;  % overlapping region
    
%     sadmap=zeros((size(warped_img1,1)),(size(warped_img1,2)));
   sadmap=zeros((size(a1,1)),(size(a1,2)));
    [i,j]=find(C==1);
    for kk =1:length(i)  % kk = C��Ϊ1�ĸ�����
    px=i(kk);py=j(kk);
%     x=warped_img1(px,py,:);y=warped_img2(px,py,:);
     x=a1(px,py,:);y=a2(px,py,:);x_1=sum(x)/size(a1,3);y_1=sum(y)/size(a1,3);
    s1=0;s2=0;s3=0;
     for k=1:size(a1,3)  % k = ������������Ϊ176��
         x1=reshape(x,[],1);y1=reshape(y,[],1);b=(x1'*y1)/(x1'*x1);
         d(k)=abs(y(k)-b*x(k)); 
         w(k)=x(k)/(1+d(k));
    s1=s1+w(k)*(x(k)-x_1)*(y(k)-y_1);
    s2=s2+w(k)*(x(k)-x_1)*(x(k)-x_1);
    s3=s3+w(k)*(y(k)-y_1)*(y(k)-y_1);
     end
     s=s1/(sqrt(s2)*sqrt(s3));
     sad2=acos(s);
     sadmap(px,py)=sad2;
%       sadmap(px,py)=s;
%     tmp=sad(wrap1(px,py,:),wrap2(px,py,:));
    end
%     reshape(z,[],1);
 