
#ifndef __GRAPHCUTMEX_H__
#define __GRAPHCUTMEX_H__

#include "graph.h"
#include "graph.cpp"
#include "maxflow.cpp"

#endif
