x=p2;
% y=p2;
y=[p31,p32(:,2:50),p33(:,2:42),p34(:,2:37)];
% y=[p21,p22(:,2:50),p23(:,2:42),p24(:,2:37)];

a1=cell2mat(struct2cell(load('g08_71-99.mat')));
a1 = imresize(a1, 0.5);
a2=cell2mat(struct2cell(load('g09_71-99.mat')));
a2 = imresize(a2, 0.5);

s1=0;s2=0;s3=0;
for i=1:176
    s1=s1+x(i)*y(i);
    s2=s2+x(i)*x(i);
    s3=s3+y(i)*y(i);
end
s=s1/(sqrt(s2)*sqrt(s3));
sad2=acos(s);
% my2 = cell2mat(struct2cell(load('2.1.jpg')));


